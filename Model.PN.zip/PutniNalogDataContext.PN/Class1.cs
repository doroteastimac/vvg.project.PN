using System;

namespace PutniNalogDataContext.PN
{
    public class Class1
    {
    }
}
